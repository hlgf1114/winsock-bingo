#pragma once
#include <winsock2.h>
#include <stdbool.h>
#include <sys/types.h>

IN_ADDR getIpAddr(char* name);
